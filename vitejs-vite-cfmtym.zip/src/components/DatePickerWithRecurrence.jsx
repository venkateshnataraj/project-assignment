// src/components/DatePickerWithRecurrence.jsx
export default function DatePickerWithRecurrence() {
  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold text-blue-500">Date Picker Loaded!</h1>
    </div>
  );
}
